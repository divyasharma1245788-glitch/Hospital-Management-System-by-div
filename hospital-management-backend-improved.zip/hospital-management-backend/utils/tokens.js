const jwt = require('jsonwebtoken');
exports.createAccessToken = user => jwt.sign({ sub: user._id.toString(), role: user.role }, process.env.JWT_ACCESS_SECRET, { expiresIn: `${process.env.ACCESS_TOKEN_MINUTES || 15}m` });
exports.createRefreshToken = user => jwt.sign({ sub: user._id.toString(), type: 'refresh' }, process.env.JWT_REFRESH_SECRET, { expiresIn: `${process.env.REFRESH_TOKEN_DAYS || 7}d` });
