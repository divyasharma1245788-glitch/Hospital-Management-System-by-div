const User=require('../models/User'); const Department=require('../models/Department'); const Appointment=require('../models/Appointment'); const Prescription=require('../models/Prescription'); const asyncHandler=require('../utils/asyncHandler'); const {logAction}=require('../utils/audit');
exports.createDepartment=asyncHandler(async(req,res)=>{const d=await Department.create(req.body);res.status(201).json(d);});
exports.listDepartments=asyncHandler(async(req,res)=>res.json(await Department.find().sort({name:1})));
exports.createPatient=asyncHandler(async(req,res)=>{const {name,email,password}=req.body;const p=await User.create({name,email,password,role:'patient'});res.status(201).json({id:p._id,name:p.name,email:p.email,role:p.role});});
exports.bookAppointment=asyncHandler(async(req,res)=>{const patientId=req.user.role==='patient'?req.user._id:req.body.patient;const doctor=await User.findOne({_id:req.body.doctor,role:'doctor',isBlocked:false});if(!doctor)return res.status(400).json({message:'Valid doctor required'});if(!patientId)return res.status(400).json({message:'Patient required'});const patient=await User.findOne({_id:patientId,role:'patient'});if(!patient)return res.status(400).json({message:'Valid patient required'});const a=await Appointment.create({patient:patientId,doctor:doctor._id,department:req.body.department,scheduledAt:req.body.scheduledAt,reason:req.body.reason});await logAction(req,'appointment_created','Appointment',a._id);res.status(201).json(a);});
exports.listAppointments=asyncHandler(async(req,res)=>{const filter={};if(req.user.role==='patient')filter.patient=req.user._id;else if(req.user.role==='doctor')filter.doctor=req.user._id;else if(req.query.patient)filter.patient=req.query.patient;const rows=await Appointment.find(filter).populate('patient','name email').populate('doctor','name email').populate('department','name').sort({scheduledAt:-1});res.json(rows);});
exports.updateAppointment=asyncHandler(async(req,res)=>{
  const allowedKeys=['status','scheduledAt'];
  if(Object.keys(req.body).some(key=>!allowedKeys.includes(key))) return res.status(400).json({message:'Only status and scheduledAt can be updated'});
  const a=await Appointment.findById(req.params.id);
  if(!a)return res.status(404).json({message:'Appointment not found'});
  const role=req.user.role;
  if(role==='patient'){
    if(!a.patient.equals(req.user._id))return res.status(403).json({message:'You can access only your own appointments'});
    if(req.body.scheduledAt || (req.body.status && req.body.status!=='cancelled')) return res.status(403).json({message:'Patients may only cancel their own appointments'});
  } else if(role==='doctor'){
    if(!a.doctor.equals(req.user._id))return res.status(403).json({message:'You can access only your assigned appointments'});
    if(req.body.scheduledAt || (req.body.status && !['completed','cancelled'].includes(req.body.status))) return res.status(403).json({message:'Doctors may only update appointment status'});
  } else if(role==='receptionist'){
    if(req.body.status && !['booked','cancelled'].includes(req.body.status)) return res.status(403).json({message:'Receptionists cannot mark appointments completed'});
  }
  if(req.body.status){
    if(!['booked','completed','cancelled'].includes(req.body.status))return res.status(400).json({message:'Invalid appointment status'});
    if(a.status==='cancelled' && req.body.status!=='cancelled')return res.status(400).json({message:'Cancelled appointments cannot be reopened'});
    a.status=req.body.status;
  }
  if(req.body.scheduledAt){
    const date=new Date(req.body.scheduledAt);
    if(Number.isNaN(date.getTime()) || date <= new Date())return res.status(400).json({message:'scheduledAt must be a valid future date'});
    a.scheduledAt=date;
  }
  await a.save();
  await logAction(req,'appointment_updated','Appointment',a._id,{status:a.status});
  res.json(a);
});
exports.deleteAppointment=asyncHandler(async(req,res)=>{const a=await Appointment.findById(req.params.id);if(!a)return res.status(404).json({message:'Appointment not found'});if(req.user.role!=='admin'&&!a.patient.equals(req.user._id))return res.status(403).json({message:'You can cancel only your own appointment'});a.status='cancelled';await a.save();await logAction(req,'appointment_cancelled','Appointment',a._id);res.json({message:'Appointment cancelled'});});
exports.createPrescription=asyncHandler(async(req,res)=>{const a=await Appointment.findById(req.body.appointment);if(!a)return res.status(404).json({message:'Appointment not found'});if(req.user.role!=='admin'&&!a.doctor.equals(req.user._id))return res.status(403).json({message:'Doctor can prescribe only for their assigned appointment'});const p=await Prescription.create({appointment:a._id,patient:a.patient,doctor:a.doctor,diagnosis:req.body.diagnosis,medicines:req.body.medicines||[],notes:req.body.notes});await logAction(req,'prescription_created','Prescription',p._id);res.status(201).json(p);});
exports.listPrescriptions=asyncHandler(async(req,res)=>{const filter={};if(req.user.role==='patient')filter.patient=req.user._id;else if(req.user.role==='doctor')filter.doctor=req.user._id;res.json(await Prescription.find(filter).populate('patient','name').populate('doctor','name').populate('appointment','scheduledAt status'));});
exports.auditLogs=asyncHandler(async(req,res)=>{const Audit=require('../models/AuditLog');const page=Math.max(1,Number(req.query.page)||1),limit=Math.min(100,Number(req.query.limit)||20);res.json(await Audit.find().populate('actor','name email').sort({createdAt:-1}).skip((page-1)*limit).limit(limit));});
