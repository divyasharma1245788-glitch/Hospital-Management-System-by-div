const jwt = require('jsonwebtoken');
const User = require('../models/User');
const asyncHandler = require('../utils/asyncHandler');
exports.authenticate = asyncHandler(async (req,res,next) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return res.status(401).json({message:'Access token required'});
  let payload; try { payload = jwt.verify(header.slice(7), process.env.JWT_ACCESS_SECRET); } catch { return res.status(401).json({message:'Invalid or expired access token'}); }
  const user = await User.findById(payload.sub);
  if (!user || user.isBlocked) return res.status(401).json({message:'Account unavailable'});
  req.user = user; next();
});
exports.authorize = (...roles) => (req,res,next) => roles.includes(req.user.role) ? next() : res.status(403).json({message:'Forbidden: insufficient role'});
