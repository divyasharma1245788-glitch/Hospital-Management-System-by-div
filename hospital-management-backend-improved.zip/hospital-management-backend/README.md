# Hospital Management System — Backend (Project 1)

A REST API built with **Node.js, Express.js and MongoDB/Mongoose**. It demonstrates authentication, authorization, role-based access control, ownership checks, CRUD operations, input validation, audit logging and secure password handling.

## Requirements
- Node.js 18 or newer
- MongoDB local instance or MongoDB Atlas database
- Postman (for API demonstration)

## Setup
```bash
npm install
cp .env.example .env
```
Open `.env` and set your MongoDB URI and two different, long, random JWT secrets. Keep `.env private; it is ignored by Git. Do not upload it to GitHub.

Create the first administrator using the one-time seed command:
```bash
npm run seed:admin
```
Set `ADMIN_NAME`, `ADMIN_EMAIL` and a strong `ADMIN_PASSWORD` in `.env` before running it. Public registration always creates a **patient**; users cannot choose the admin role themselves.

Start the API:
```bash
npm run dev
```
Health check: `GET http://localhost:5000/api/health`

## Roles and permissions
- **Admin:** manage departments and users, assign roles, block/unblock accounts and view audit logs.
- **Doctor:** view assigned appointments, update permitted appointment statuses and create prescriptions only for assigned appointments.
- **Receptionist:** register patients and manage appointment bookings/scheduling.
- **Patient:** book appointments and view or cancel only their own appointments; view only their own prescriptions.

## Main API routes
Send JSON request bodies. For protected routes use `Authorization: Bearer <accessToken>`.

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | Public | Register a patient (never an admin) |
| POST | `/api/auth/login` | Public, rate-limited | Login and receive access/refresh tokens |
| POST | `/api/auth/refresh` | Refresh token | Rotate the refresh token |
| POST | `/api/auth/logout` | Authenticated | Revoke the supplied refresh token |
| GET | `/api/auth/me` | Authenticated | Get current user profile |
| POST | `/api/auth/forgot-password` | Public, rate-limited | Send reset email when SMTP is configured |
| POST | `/api/auth/reset-password` | Reset token | Set a new password |
| GET | `/api/departments` | Public | List departments |
| POST | `/api/departments` | Admin | Create a department |
| POST | `/api/patients` | Admin/Receptionist | Create a patient |
| POST | `/api/appointments` | Authenticated roles | Book an appointment |
| GET | `/api/appointments` | Authenticated roles | List appointments allowed for the current role |
| PATCH | `/api/appointments/:id` | Authenticated roles | Update only permitted appointment fields/statuses |
| DELETE | `/api/appointments/:id` | Admin/owning Patient | Cancel appointment |
| POST | `/api/prescriptions` | Admin/Doctor | Create prescription (doctor must be assigned) |
| GET | `/api/prescriptions` | Admin/Doctor/Patient | List permitted prescriptions |
| GET | `/api/admin/users` | Admin | Search/filter/paginate users |
| PATCH | `/api/admin/users/:id/role` | Admin | Change a user's role |
| PATCH | `/api/admin/users/:id/block` | Admin | Block/unblock user; body `{ "blocked": true }` |
| GET | `/api/admin/audit-logs` | Admin | View audit history |

## Example requests
Register patient — `POST /api/auth/register`:
```json
{"name":"Aarav Sharma","email":"aarav@example.com","password":"StrongPass123!"}
```
Login — `POST /api/auth/login`:
```json
{"email":"aarav@example.com","password":"StrongPass123!"}
```
Book appointment as a patient — `POST /api/appointments`:
```json
{"doctor":"DOCTOR_OBJECT_ID","scheduledAt":"2026-11-05T10:30:00.000Z","reason":"General check-up"}
```
Receptionist/admin booking for a patient must also include `patient` ID.

## Security controls
- Passwords are hashed using bcrypt (12 salt rounds); password fields are excluded from normal database queries and never included in API responses.
- Public registration hardcodes the `patient` role. Admin creation is performed only by the server-side seed script.
- JWT access tokens are short-lived; refresh tokens are stored as SHA-256 hashes and rotated on use.
- Logout only revokes the refresh token supplied by the authenticated user; it does not accidentally clear a different/newer session.
- Password reset tokens are hashed and expire after 15 minutes. **Reset tokens are never returned in API responses.** Configure SMTP variables in `.env` to send reset links; without SMTP the endpoint returns a generic message and does not create a usable reset token.
- Patients can only cancel their own appointments; doctors can only update their assigned appointments; only admins/receptionists can reschedule; doctors cannot prescribe for another doctor's appointment.
- The last active administrator cannot be demoted, and an admin cannot remove their own admin role.
- Input validation uses `express-validator`; request body size is limited; login/reset endpoints are rate-limited.
- Helmet security headers, restricted CORS origins, centralized error handling and audit logging are enabled.
- `.env`, dependencies and log files are excluded by `.gitignore`.

## Password-reset email configuration (optional)
Fill in `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `SMTP_FROM` and `PASSWORD_RESET_URL` in `.env`. Never put SMTP credentials in source code or GitHub. The reset page at `PASSWORD_RESET_URL` should read the `token` query parameter and submit it with the new password to `POST /api/auth/reset-password`.

## Postman demo / viva sequence
1. Call the health endpoint.
2. Run `npm run seed:admin` once, then log in as the seeded admin.
3. As admin, create a department and register a patient; promote a separate account to doctor/receptionist for the demo.
4. Register/login as a patient and book an appointment with the doctor's MongoDB ID.
5. Login as the assigned doctor, view the appointment and create a prescription.
6. Login as patient and show that only their own appointments/prescriptions are returned.
7. As admin, demonstrate user listing, role change, block/unblock and audit logs.
8. Demonstrate invalid login, rate limiting, refresh-token rotation, logout and forbidden-role responses.
9. Demonstrate that public registration with `{"role":"admin"}` still creates a patient and that no API response contains a password or reset token.

## Before GitHub submission
```bash
git status
```
Confirm `.env` is not listed. Commit `.env.example`, not `.env`. Also replace all sample credentials and secrets in your private `.env` file before running the server.

## Important note
This is an educational backend project, not a production-ready clinical system. Do not use real patient data. A real deployment would require additional privacy, compliance, monitoring, backup and security reviews.
