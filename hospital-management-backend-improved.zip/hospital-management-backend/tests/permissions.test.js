const test = require('node:test');
const assert = require('node:assert/strict');
const { hasPermission } = require('../middlewares/permissions');

function runPermission(role, permission) {
  const req = { user: { role } };
  let statusCode;
  let payload;
  let continued = false;
  const res = {
    status(code) { statusCode = code; return this; },
    json(body) { payload = body; return this; }
  };
  hasPermission(permission)(req, res, () => { continued = true; });
  return { statusCode, payload, continued };
}

test('patient can create own appointment', () => {
  assert.equal(runPermission('patient', 'appointment:create:own').continued, true);
});

test('patient cannot manage departments', () => {
  const result = runPermission('patient', 'department:manage');
  assert.equal(result.continued, false);
  assert.equal(result.statusCode, 403);
  assert.equal(result.payload.message, 'Forbidden: missing permission');
});

test('doctor can create own prescriptions', () => {
  assert.equal(runPermission('doctor', 'prescription:create:own').continued, true);
});
