module.exports = (err, req, res, next) => {
  if (res.headersSent) return next(err);
  if (err.code === 11000) return res.status(409).json({ message: 'A record with this value already exists' });
  if (err.name === 'ValidationError' || err.name === 'CastError' || err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Invalid request data' });
  }
  if (err.message === 'Origin not allowed by CORS') return res.status(403).json({ message: 'Origin not allowed' });
  const status = Number(err.status) || 500;
  if (status >= 500) console.error(err);
  return res.status(status).json({ message: status >= 500 ? 'Internal server error' : err.message });
};
