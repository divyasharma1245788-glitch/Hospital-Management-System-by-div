const mongoose = require('mongoose');
module.exports = mongoose.model('AuditLog', new mongoose.Schema({ actor:{type:mongoose.Schema.Types.ObjectId,ref:'User'}, action:String, resource:String, resourceId:String, details:Object, ip:String }, {timestamps:true}));
