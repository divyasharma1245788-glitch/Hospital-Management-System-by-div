const AuditLog = require('../models/AuditLog');
exports.logAction = async (req, action, resource, resourceId, details = {}) => {
  try { await AuditLog.create({ actor: req.user?._id, action, resource, resourceId: resourceId?.toString(), details, ip: req.ip }); }
  catch (error) { console.error('Audit log failed:', error.message); }
};
