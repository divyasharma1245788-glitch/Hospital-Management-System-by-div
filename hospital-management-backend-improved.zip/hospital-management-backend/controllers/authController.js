const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const RefreshToken = require('../models/RefreshToken');
const asyncHandler = require('../utils/asyncHandler');
const { createAccessToken, createRefreshToken } = require('../utils/tokens');
const { logAction } = require('../utils/audit');
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const refreshExpiry = () => new Date(Date.now() + (Number(process.env.REFRESH_TOKEN_DAYS) || 7) * 86400000);

exports.register = asyncHandler(async (req, res) => {
  const { name, email, password } = req.body;
  const user = await User.create({ name, email, password, role: 'patient' });
  res.status(201).json({ message: 'Patient registered', user: { id: user._id, name: user.name, email: user.email, role: user.role } });
});

exports.login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email: String(email).toLowerCase() }).select('+password +refreshTokenHash');
  if (!user || user.isBlocked) return res.status(401).json({ message: 'Invalid credentials or blocked account' });
  if (user.lockUntil && user.lockUntil > Date.now()) return res.status(423).json({ message: 'Account temporarily locked. Try again later.' });
  if (!(await user.comparePassword(password || ''))) {
    user.failedLoginAttempts += 1;
    if (user.failedLoginAttempts >= 5) {
      user.lockUntil = new Date(Date.now() + 15 * 60 * 1000);
      user.failedLoginAttempts = 0;
    }
    await user.save();
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  user.failedLoginAttempts = 0;
  user.lockUntil = null;
  const accessToken = createAccessToken(user);
  const refreshToken = createRefreshToken(user);
  user.refreshTokenHash = hash(refreshToken);
  await user.save();
  await RefreshToken.deleteMany({ user: user._id });
  await RefreshToken.create({ user: user._id, tokenHash: hash(refreshToken), expiresAt: refreshExpiry() });
  await logAction(req, 'login', 'User', user._id);
  return res.json({ accessToken, refreshToken, user: { id: user._id, name: user.name, email: user.email, role: user.role } });
});

exports.refresh = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(401).json({ message: 'Refresh token required' });
  let payload;
  try { payload = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET); }
  catch { return res.status(401).json({ message: 'Invalid refresh token' }); }
  if (payload.type !== 'refresh' || !payload.sub) return res.status(401).json({ message: 'Invalid refresh token' });
  const tokenHash = hash(refreshToken);
  const user = await User.findById(payload.sub).select('+refreshTokenHash');
  if (!user || user.isBlocked || user.refreshTokenHash !== tokenHash) return res.status(401).json({ message: 'Refresh token revoked' });
  const tokenDoc = await RefreshToken.findOneAndDelete({ user: user._id, tokenHash, expiresAt: { $gt: new Date() } });
  if (!tokenDoc) return res.status(401).json({ message: 'Refresh token revoked or already used' });
  const nextRefresh = createRefreshToken(user);
  user.refreshTokenHash = hash(nextRefresh);
  await user.save();
  await RefreshToken.create({ user: user._id, tokenHash: hash(nextRefresh), expiresAt: refreshExpiry() });
  return res.json({ accessToken: createAccessToken(user), refreshToken: nextRefresh });
});

exports.logout = asyncHandler(async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    const tokenHash = hash(refreshToken);
    await RefreshToken.deleteOne({ user: req.user._id, tokenHash });
    const user = await User.findById(req.user._id).select('+refreshTokenHash');
    // Do not revoke a newer session when an old token is supplied.
    if (user && user.refreshTokenHash === tokenHash) {
      user.refreshTokenHash = null;
      await user.save();
    }
  }
  await logAction(req, 'logout', 'User', req.user._id);
  return res.json({ message: 'Logged out; supplied refresh token invalidated' });
});

exports.me = (req, res) => res.json({ user: { id: req.user._id, name: req.user.name, email: req.user.email, role: req.user.role } });

exports.forgotPassword = asyncHandler(async (req, res) => {
  // Never return reset tokens in an API response. Configure SMTP to deliver reset links.
  const genericMessage = 'If the account exists and password-reset email is configured, reset instructions will be sent.';
  const user = await User.findOne({ email: String(req.body.email).toLowerCase() }).select('+resetTokenHash +resetTokenExpires');
  if (!user) return res.json({ message: genericMessage });
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS || !process.env.PASSWORD_RESET_URL) {
    return res.json({ message: genericMessage });
  }
  const token = crypto.randomBytes(32).toString('hex');
  user.resetTokenHash = hash(token);
  user.resetTokenExpires = new Date(Date.now() + 15 * 60 * 1000);
  await user.save();
  try {
    const nodemailer = require('nodemailer');
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 587,
      secure: process.env.SMTP_SECURE === 'true',
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
    const resetUrl = `${process.env.PASSWORD_RESET_URL}?token=${encodeURIComponent(token)}`;
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER,
      to: user.email,
      subject: 'Hospital Management System - Password reset',
      text: `Use this link to reset your password. It expires in 15 minutes: ${resetUrl}`
    });
  } catch (error) {
    user.resetTokenHash = null;
    user.resetTokenExpires = null;
    await user.save();
    console.error('Password reset email could not be sent:', error.message);
  }
  return res.json({ message: genericMessage });
});

exports.resetPassword = asyncHandler(async (req, res) => {
  const user = await User.findOne({ resetTokenHash: hash(req.body.token || ''), resetTokenExpires: { $gt: new Date() } })
    .select('+resetTokenHash +resetTokenExpires +refreshTokenHash');
  if (!user) return res.status(400).json({ message: 'Invalid or expired reset token' });
  user.password = req.body.password;
  user.resetTokenHash = null;
  user.resetTokenExpires = null;
  user.refreshTokenHash = null;
  await user.save();
  await RefreshToken.deleteMany({ user: user._id });
  return res.json({ message: 'Password reset successful. Please log in again.' });
});
